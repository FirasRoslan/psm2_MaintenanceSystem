

<?php $__env->startSection('title', 'Landlord Profile'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="mb-1">Landlord Profile</h4>
            <p class="text-muted mb-0">View details about this landlord</p>
        </div>
        <a href="<?php echo e(route('contractor.dashboard')); ?>" class="btn btn-outline-primary rounded-pill">
            <i class="fas fa-arrow-left me-2"></i>Back to Dashboard
        </a>
    </div>

    <div class="row">
        <div class="col-md-4 mb-4">
            <div class="card border-0 shadow-sm rounded-4">
                <div class="card-body text-center py-5">
                    <div class="avatar-lg mx-auto mb-4 bg-primary text-white">
                        <?php echo e(substr($landlord->name, 0, 1)); ?>

                    </div>
                    <h4 class="mb-1"><?php echo e($landlord->name); ?></h4>
                    <p class="text-muted mb-3">Landlord</p>
                    
                    <div class="d-flex justify-content-center mb-4">
                        <div class="px-3 border-end">
                            <h5 class="mb-0"><?php echo e($landlord->houses->count()); ?></h5>
                            <small class="text-muted">Properties</small>
                        </div>
                        <div class="px-3">
                            <h5 class="mb-0"><?php echo e($landlord->approvedContractors->count()); ?></h5>
                            <small class="text-muted">Contractors</small>
                        </div>
                    </div>
                    
                    <div class="contact-info">
                        <div class="d-flex align-items-center mb-2">
                            <div class="icon-box bg-primary-light me-3">
                                <i class="fas fa-envelope text-primary"></i>
                            </div>
                            <div class="text-start">
                                <p class="mb-0"><?php echo e($landlord->email); ?></p>
                            </div>
                        </div>
                        <div class="d-flex align-items-center">
                            <div class="icon-box bg-primary-light me-3">
                                <i class="fas fa-phone text-primary"></i>
                            </div>
                            <div class="text-start">
                                <p class="mb-0"><?php echo e($landlord->phone); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-8">
            <div class="card border-0 shadow-sm rounded-4 mb-4">
                <div class="card-header bg-white border-0">
                    <h5 class="mb-0">Properties</h5>
                </div>
                <div class="card-body">
                    <?php if($landlord->houses->count() > 0): ?>
                        <div class="list-group list-group-flush">
                            <?php $__currentLoopData = $landlord->houses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="list-group-item px-0 py-3 border-0">
                                    <div class="d-flex align-items-center">
                                        <div class="flex-shrink-0">
                                            <div class="property-image rounded">
                                                <?php if($property->house_image): ?>
                                                    <img src="<?php echo e(asset('storage/' . $property->house_image)); ?>" alt="<?php echo e($property->house_address); ?>" class="img-fluid rounded" style="width: 80px; height: 60px; object-fit: cover;">
                                                <?php else: ?>
                                                    <div class="bg-light rounded d-flex justify-content-center align-items-center" style="width: 80px; height: 60px;">
                                                        <i class="fas fa-home fa-2x text-muted"></i>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="flex-grow-1 ms-3">
                                            <h6 class="mb-1"><?php echo e($property->house_address); ?></h6>
                                            <p class="text-muted small mb-0">
                                                <i class="fas fa-door-open me-1"></i> <?php echo e($property->house_number_room); ?> <?php echo e(Str::plural('room', $property->house_number_room)); ?>

                                                <i class="fas fa-toilet ms-2 me-1"></i> <?php echo e($property->house_number_toilet); ?> <?php echo e(Str::plural('toilet', $property->house_number_toilet)); ?>

                                            </p>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-4">
                            <div class="empty-state-icon mb-3">
                                <i class="fas fa-building"></i>
                            </div>
                            <h5>No Properties</h5>
                            <p class="text-muted">This landlord hasn't added any properties yet.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="card border-0 shadow-sm rounded-4">
                <div class="card-header bg-white border-0">
                    <h5 class="mb-0">Maintenance Agreement</h5>
                </div>
                <div class="card-body">
                    <div class="mb-4">
                        <h6 class="text-muted mb-2">Maintenance Scope</h6>
                        <div class="p-3 bg-light rounded-3">
                            <p class="mb-0"><?php echo e($pivot->maintenance_scope ?? 'No maintenance scope defined'); ?></p>
                        </div>
                    </div>
                    
                    <div class="mb-4">
                        <h6 class="text-muted mb-2">Your Specialization</h6>
                        <div class="p-3 bg-light rounded-3">
                            <p class="mb-0"><?php echo e($pivot->specialization ?? 'No specialization defined'); ?></p>
                        </div>
                    </div>
                    
                    <div class="mb-0">
                        <h6 class="text-muted mb-2">Agreement Status</h6>
                        <?php if(isset($pivot) && $pivot->approval_status === true): ?>
                            <div class="alert alert-success mb-0">
                                <i class="fas fa-check-circle me-2"></i> Your agreement with this landlord is active
                            </div>
                        <?php elseif(isset($pivot) && $pivot->approval_status === null): ?>
                            <div class="alert alert-warning mb-0">
                                <i class="fas fa-clock me-2"></i> Your agreement is pending approval from the landlord
                            </div>
                        <?php else: ?>
                            <div class="alert alert-danger mb-0">
                                <i class="fas fa-times-circle me-2"></i> Your agreement with this landlord is not active
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('styles'); ?>
<style>
    .rounded-4 {
        border-radius: 0.75rem !important;
    }
    
    .avatar-lg {
        width: 100px;
        height: 100px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 2.5rem;
        font-weight: bold;
    }
    
    .icon-box {
        width: 40px;
        height: 40px;
        border-radius: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.2rem;
    }
    
    .bg-primary-light {
        background-color: rgba(13, 110, 253, 0.1);
    }
    
    .empty-state-icon {
        width: 80px;
        height: 80px;
        border-radius: 50%;
        background-color: #f8f9fa;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto;
        font-size: 2rem;
        color: #adb5bd;
    }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('ui.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\psm2\resources\views/contractor/landlord-profile.blade.php ENDPATH**/ ?>