

<?php $__env->startSection('title', 'Add Room'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow-sm">
                <div class="card-header bg-transparent">
                    <h5 class="mb-0">Add Room to <?php echo e($house->house_address); ?></h5>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('landlord.properties.rooms.store', $house->houseID)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        
                        <div class="mb-3">
                            <label for="room_type" class="form-label">Room Type</label>
                            <select class="form-select <?php $__errorArgs = ['room_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="room_type" name="room_type" required>
                                <option value="">Select Room Type</option>
                                <option value="Living Room" <?php echo e(old('room_type') == 'Living Room' ? 'selected' : ''); ?>>Living Room</option>
                                <option value="Bedroom" <?php echo e(old('room_type') == 'Bedroom' ? 'selected' : ''); ?>>Bedroom</option>
                                <option value="Kitchen" <?php echo e(old('room_type') == 'Kitchen' ? 'selected' : ''); ?>>Kitchen</option>
                                <option value="Bathroom" <?php echo e(old('room_type') == 'Bathroom' ? 'selected' : ''); ?>>Bathroom</option>
                                <option value="Dining Room" <?php echo e(old('room_type') == 'Dining Room' ? 'selected' : ''); ?>>Dining Room</option>
                                <option value="Study Room" <?php echo e(old('room_type') == 'Study Room' ? 'selected' : ''); ?>>Study Room</option>
                                <option value="Laundry Room" <?php echo e(old('room_type') == 'Laundry Room' ? 'selected' : ''); ?>>Laundry Room</option>
                                <option value="Other" <?php echo e(old('room_type') == 'Other' ? 'selected' : ''); ?>>Other</option>
                            </select>
                            <?php $__errorArgs = ['room_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <div class="mb-4">
                            <label for="room_image" class="form-label">Room Image</label>
                            <input type="file" class="form-control <?php $__errorArgs = ['room_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   id="room_image" name="room_image" accept="image/jpeg,image/png,image/jpg" required>
                            <?php $__errorArgs = ['room_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <div id="imagePreview" class="mt-2"></div>
                        </div>
                        
                        <div class="d-flex justify-content-between">
                            <a href="<?php echo e(route('landlord.properties.show', $house->houseID)); ?>" class="btn btn-outline-secondary">Cancel</a>
                            <button type="submit" class="btn btn-primary">Add Room</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    // Image preview functionality
    document.getElementById('room_image').addEventListener('change', function(e) {
        const file = e.target.files[0];
        if (file && file.type.startsWith('image/')) {
            const reader = new FileReader();
            reader.onload = function(e) {
                const preview = document.createElement('img');
                preview.src = e.target.result;
                preview.style.maxWidth = '100%';
                preview.style.maxHeight = '200px';
                preview.className = 'rounded';
                
                const previewContainer = document.getElementById('imagePreview');
                previewContainer.innerHTML = '';
                previewContainer.appendChild(preview);
            }
            reader.readAsDataURL(file);
        }
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('ui.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\psm2\resources\views/landlord/properties/rooms/create.blade.php ENDPATH**/ ?>